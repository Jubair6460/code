
import { User, BombLog, RedeemCode, SystemStats } from '../types';

const MOCK_DELAY = 500;

const initMockData = () => {
  if (!localStorage.getItem('cyberpulse_users')) {
    const users: User[] = [
      { id: 1, username: 'owner', firstName: 'Admin', diamonds: 99999, totalBombs: 15, referralCode: 'OWNERPRO', referredBy: null, referralCount: 5, dailyBonusClaimed: null, joinedDate: new Date().toISOString(), lastActive: new Date().toISOString(), isBlocked: false, isAdmin: true, safeList: [] },
      { id: 101, username: 'testuser', firstName: 'John', diamonds: 500, totalBombs: 3, referralCode: 'JOHNDOE123', referredBy: 1, referralCount: 2, dailyBonusClaimed: new Date(Date.now() - 86400000).toISOString(), joinedDate: new Date().toISOString(), lastActive: new Date().toISOString(), isBlocked: false, isAdmin: false, safeList: ['01700000000'] },
      { id: 102, username: 'janedoe', firstName: 'Jane', diamonds: 1200, totalBombs: 10, referralCode: 'JANEDOE456', referredBy: null, referralCount: 8, dailyBonusClaimed: new Date().toISOString(), joinedDate: new Date().toISOString(), lastActive: new Date().toISOString(), isBlocked: false, isAdmin: false, safeList: [] },
      { id: 103, username: 'blockeduser', firstName: 'Banned', diamonds: 10, totalBombs: 1, referralCode: 'BLOCKED789', referredBy: 101, referralCount: 0, dailyBonusClaimed: null, joinedDate: new Date().toISOString(), lastActive: new Date().toISOString(), isBlocked: true, isAdmin: false, safeList: [] },
    ];
    localStorage.setItem('cyberpulse_users', JSON.stringify(users));
  }
  if (!localStorage.getItem('cyberpulse_blacklist')) {
    localStorage.setItem('cyberpulse_blacklist', JSON.stringify(['01811111111']));
  }
   if (!localStorage.getItem('cyberpulse_codes')) {
    const codes: RedeemCode[] = [
        { code: 'WELCOME100', amount: 100, maxUsers: 50, usedBy: [102], isActive: true, createdAt: new Date().toISOString(), createdBy: 1 },
        { code: 'EXPIRED', amount: 50, maxUsers: 2, usedBy: [101, 102], isActive: false, createdAt: new Date().toISOString(), createdBy: 1 }
    ];
    localStorage.setItem('cyberpulse_codes', JSON.stringify(codes));
  }
};

initMockData();

const db = {
  getUsers: (): User[] => JSON.parse(localStorage.getItem('cyberpulse_users') || '[]'),
  saveUsers: (users: User[]) => localStorage.setItem('cyberpulse_users', JSON.stringify(users)),
  getBlacklist: (): string[] => JSON.parse(localStorage.getItem('cyberpulse_blacklist') || '[]'),
  saveBlacklist: (list: string[]) => localStorage.setItem('cyberpulse_blacklist', JSON.stringify(list)),
  getCodes: (): RedeemCode[] => JSON.parse(localStorage.getItem('cyberpulse_codes') || '[]'),
  saveCodes: (codes: RedeemCode[]) => localStorage.setItem('cyberpulse_codes', JSON.stringify(codes)),
};


const simulateApi = <T,>(data: T, shouldFail: boolean = false): Promise<T> => {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            if (shouldFail) {
                reject(new Error("Simulated API Error"));
            } else {
                resolve(data);
            }
        }, MOCK_DELAY);
    });
};


export const api = {
    loginUser: (userId: number): Promise<User | null> => {
        const users = db.getUsers();
        const user = users.find(u => u.id === userId) || null;
        if(user) {
            user.lastActive = new Date().toISOString();
            db.saveUsers(users);
        }
        return simulateApi(user);
    },
    
    claimDailyBonus: async (userId: number): Promise<{ amount: number; user: User }> => {
        const users = db.getUsers();
        const user = users.find(u => u.id === userId);
        if (!user) throw new Error("User not found");

        const today = new Date().toISOString().split('T')[0];
        if (user.dailyBonusClaimed && user.dailyBonusClaimed.startsWith(today)) {
            throw new Error("Bonus already claimed today.");
        }
        
        const bonusAmount = 200;
        user.diamonds += bonusAmount;
        user.dailyBonusClaimed = new Date().toISOString();
        db.saveUsers(users);
        return simulateApi({ amount: bonusAmount, user });
    },

    sendSmsBomb: async (userId: number, target: string, amount: number): Promise<{ success: boolean; message: string; user: User; }> => {
        const blacklist = db.getBlacklist();
        const users = db.getUsers();
        const user = users.find(u => u.id === userId);
        if (!user) return simulateApi({ success: false, message: 'User not found', user: user! });

        const allSafeLists = users.flatMap(u => u.safeList);
        if (blacklist.includes(target) || allSafeLists.includes(target)) {
            return simulateApi({ success: false, message: 'This number is protected and cannot be targeted.', user });
        }
        
        const cost = amount * 1;
        if (user.diamonds < cost) {
            return simulateApi({ success: false, message: 'Insufficient diamonds.', user });
        }

        user.diamonds -= cost;
        user.totalBombs += 1;
        db.saveUsers(users);

        return simulateApi({ success: true, message: `Attack on ${target} initiated successfully!`, user });
    },

    redeemCode: async (userId: number, code: string): Promise<{ success: boolean; message: string; user: User; }> => {
        const codes = db.getCodes();
        const users = db.getUsers();
        const user = users.find(u => u.id === userId);
        const codeData = codes.find(c => c.code === code);

        if(!user) return simulateApi({ success: false, message: 'User not found.', user: user! });
        if(!codeData) return simulateApi({ success: false, message: 'Invalid redeem code.', user });
        if(!codeData.isActive) return simulateApi({ success: false, message: 'This code is no longer active.', user });
        if(codeData.usedBy.includes(userId)) return simulateApi({ success: false, message: 'You have already used this code.', user });
        if(codeData.usedBy.length >= codeData.maxUsers) return simulateApi({ success: false, message: 'This code has reached its usage limit.', user });

        user.diamonds += codeData.amount;
        codeData.usedBy.push(userId);
        
        db.saveUsers(users);
        db.saveCodes(codes);
        
        return simulateApi({ success: true, message: `Successfully redeemed ${codeData.amount} diamonds!`, user });
    },

    addToSafeList: async(userId: number, phone: string): Promise<{success: boolean; user: User}> => {
        const users = db.getUsers();
        const user = users.find(u => u.id === userId);
        if(!user) throw new Error("User not found");
        if(!user.safeList.includes(phone)) {
            user.safeList.push(phone);
        }
        db.saveUsers(users);
        return simulateApi({success: true, user});
    },

    removeFromSafeList: async(userId: number, phone: string): Promise<{success: boolean; user: User}> => {
        const users = db.getUsers();
        const user = users.find(u => u.id === userId);
        if(!user) throw new Error("User not found");
        user.safeList = user.safeList.filter(p => p !== phone);
        db.saveUsers(users);
        return simulateApi({success: true, user});
    },
    
    getLeaderboards: async (): Promise<{ diamonds: User[], bombs: User[], referrals: User[] }> => {
        const users = db.getUsers().filter(u => !u.isAdmin);
        const diamonds = [...users].sort((a, b) => b.diamonds - a.diamonds).slice(0, 10);
        const bombs = [...users].sort((a, b) => b.totalBombs - a.totalBombs).slice(0, 10);
        const referrals = [...users].sort((a, b) => b.referralCount - a.referralCount).slice(0, 10);
        return simulateApi({ diamonds, bombs, referrals });
    },
    
    // Admin functions
    getAllUsers: () => simulateApi(db.getUsers()),
    updateUser: (user: User) => {
        const users = db.getUsers();
        const index = users.findIndex(u => u.id === user.id);
        if(index > -1) {
            users[index] = user;
            db.saveUsers(users);
            return simulateApi(user);
        }
        throw new Error("User not found to update");
    },
    getBlacklist: () => simulateApi(db.getBlacklist()),
    addToBlacklist: (phone: string) => {
        const list = db.getBlacklist();
        if(!list.includes(phone)) {
            list.push(phone);
            db.saveBlacklist(list);
        }
        return simulateApi(list);
    },
    removeFromBlacklist: (phone: string) => {
        let list = db.getBlacklist();
        list = list.filter(p => p !== phone);
        db.saveBlacklist(list);
        return simulateApi(list);
    },
     getAllCodes: () => simulateApi(db.getCodes()),
    createCode: (code: RedeemCode) => {
        const codes = db.getCodes();
        codes.push(code);
        db.saveCodes(codes);
        return simulateApi(code);
    },
    deleteCode: (code: string) => {
        let codes = db.getCodes();
        codes = codes.filter(c => c.code !== code);
        db.saveCodes(codes);
        return simulateApi(codes);
    }
};
