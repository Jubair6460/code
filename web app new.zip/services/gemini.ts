
import { GoogleGenAI } from "@google/genai";

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  console.warn("Gemini API key not found. Generative features will be disabled.");
}

const ai = new GoogleGenAI({ apiKey: API_KEY! });

export const geminiService = {
  generateCreativeMessage: async (prompt: string): Promise<string> => {
    if (!API_KEY) {
      return Promise.resolve("The generative AI service is currently unavailable. Please check the API key configuration.");
    }
    
    try {
      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: `Generate a short, witty, and slightly annoying prank message based on the following theme. Keep it under 150 characters. Theme: "${prompt}"`,
      });
      return response.text ?? "Sorry, I couldn't come up with a message right now.";
    } catch (error) {
      console.error("Error generating content with Gemini:", error);
      return "An error occurred while generating the message.";
    }
  },
};
