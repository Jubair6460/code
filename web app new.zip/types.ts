
export interface User {
  id: number;
  username: string;
  firstName: string;
  diamonds: number;
  totalBombs: number;
  referralCode: string;
  referredBy: number | null;
  referralCount: number;
  dailyBonusClaimed: string | null; // ISO Date string
  joinedDate: string; // ISO Date string
  lastActive: string; // ISO Date string
  isBlocked: boolean;
  isAdmin: boolean;
  safeList: string[];
}

export interface BombLog {
  id: string;
  userId: number;
  targetNumber: string;
  amount: number;
  cost: number;
  timestamp: string; // ISO Date string
  status: 'started' | 'completed' | 'failed';
}

export interface RedeemCode {
  code: string;
  amount: number;
  maxUsers: number;
  usedBy: number[];
  isActive: boolean;
  createdAt: string; // ISO Date string
  createdBy: number;
}

export interface SystemStats {
  users: number;
  activeToday: number;
  bombs: number;
  diamonds: number;
  bannedUsers: number;
  blacklistedNumbers: number;
  recentBombs24h: number;
}

export interface ToastMessage {
  id: number;
  message: string;
  type: 'success' | 'error' | 'info';
}

export enum UserPanelView {
  Dashboard,
  Bomb,
  Redeem,
  Referral,
  Profile,
  Leaderboard,
  Help,
  ApiStatus,
  SafeList,
}

export enum AdminPanelView {
  Dashboard,
  UserManagement,
  UserList,
  Broadcast,
  Maintenance,
  RedeemCodes,
  Blacklist,
  Settings,
}
