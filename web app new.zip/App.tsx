
import React, { useState, useEffect, useCallback } from 'react';
import { User, ToastMessage } from './types';
import { api } from './services/api';
import UserPanel from './components/UserPanel';
import AdminPanel from './components/AdminPanel';
import { Toast } from './components/common/Toast';
import { LockIcon } from './components/icons';

// Mock user IDs for demonstration
const USER_ID = 101;
const ADMIN_ID = 1; // This user is also the owner in mock data

const App: React.FC = () => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(false);
  const [isLoggingIn, setIsLoggingIn] = useState<boolean>(true);
  const [toast, setToast] = useState<ToastMessage | null>(null);

  const showToast = (message: string, type: 'success' | 'error' | 'info') => {
    setToast({ id: Date.now(), message, type });
    setTimeout(() => setToast(null), 3000);
  };

  const login = useCallback(async (userId: number) => {
    setIsLoggingIn(true);
    try {
      const user = await api.loginUser(userId);
      if (user) {
        setCurrentUser(user);
        setIsAuthenticated(true);
        showToast(`Welcome back, ${user.firstName}!`, 'success');
      } else {
        showToast('Login failed: User not found.', 'error');
      }
    } catch (error) {
      showToast('An error occurred during login.', 'error');
    } finally {
      setIsLoggingIn(false);
    }
  }, []);

  useEffect(() => {
    // Auto-login as a normal user for this demo.
    // In a real app, this would be a proper login flow.
    login(USER_ID);
  }, [login]);

  if (isLoggingIn && !isAuthenticated) {
    return (
      <div className="min-h-screen bg-gray-900 flex flex-col items-center justify-center text-white">
        <div className="animate-pulse flex flex-col items-center gap-4">
          <svg className="w-16 h-16 text-green-400" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" d="M13.5 10.5V6.75a4.5 4.5 0 119 0v3.75M3.75 21.75h16.5a1.5 1.5 0 001.5-1.5v-6a1.5 1.5 0 00-1.5-1.5H3.75a1.5 1.5 0 00-1.5 1.5v6a1.5 1.5 0 001.5 1.5z" />
          </svg>
          <p className="text-lg font-semibold">Authenticating...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-900 text-gray-100 font-sans p-4">
      {toast && <Toast message={toast.message} type={toast.type} onClose={() => setToast(null)} />}
      <header className="flex justify-between items-center mb-4">
          <h1 className="text-2xl md:text-3xl font-bold text-green-400 tracking-wider">
              CyberPulse SMS
          </h1>
          {isAuthenticated && currentUser && (
              <div className="flex items-center gap-4">
                  <div className="text-right hidden sm:block">
                      <p className="font-semibold">{currentUser.firstName}</p>
                      <p className="text-sm text-gray-400">{currentUser.isAdmin ? 'Admin' : 'User'}</p>
                  </div>
                  <button
                      onClick={() => login(currentUser.id === USER_ID ? ADMIN_ID : USER_ID)}
                      className="p-2 bg-gray-800 rounded-full hover:bg-green-500 transition-colors"
                      title={currentUser.id === USER_ID ? "Switch to Admin View" : "Switch to User View"}
                  >
                      <LockIcon className="w-5 h-5"/>
                  </button>
              </div>
          )}
      </header>

      <main>
        {isAuthenticated && currentUser ? (
          currentUser.isAdmin ? (
            <AdminPanel user={currentUser} showToast={showToast} />
          ) : (
            <UserPanel user={currentUser} showToast={showToast} refreshUser={() => login(currentUser.id)}/>
          )
        ) : (
          <div className="text-center p-8">
            <h2 className="text-2xl text-red-500">Authentication Failed</h2>
            <p className="text-gray-400 mt-2">Please try refreshing the page.</p>
          </div>
        )}
      </main>
        <footer className="text-center text-gray-500 text-xs mt-8 pb-4">
            <p>&copy; {new Date().getFullYear()} CyberPulse. All rights reserved.</p>
            <p>This is a demonstration app. No real SMS messages will be sent.</p>
        </footer>
    </div>
  );
};

export default App;
