
import React, { useState, useEffect, useCallback } from 'react';
import { User, UserPanelView, ToastMessage } from '../types';
import { api } from '../services/api';
import { geminiService } from '../services/gemini';
import { BombIcon, GiftIcon, UserGroupIcon, ShieldCheckIcon, TrophyIcon, UserCircleIcon, InfoIcon, KeyIcon, DiamondIcon, SparklesIcon, TrashIcon, CloseIcon } from './icons';

interface UserPanelProps {
  user: User;
  showToast: (message: string, type: ToastMessage['type']) => void;
  refreshUser: () => void;
}

// --- Main Menu Button Component ---
const MenuButton: React.FC<{ icon: React.ReactNode; label: string; onClick: () => void; }> = ({ icon, label, onClick }) => (
    <button onClick={onClick} className="flex flex-col items-center justify-center p-4 bg-gray-800 rounded-lg text-center hover:bg-green-500 transition-all duration-200 aspect-square">
        <div className="w-8 h-8 mb-2">{icon}</div>
        <span className="text-xs font-semibold">{label}</span>
    </button>
);


// --- View Components (defined outside the main component) ---

const DashboardView: React.FC<{ user: User, setView: (view: UserPanelView) => void }> = ({ user, setView }) => {
    return (
        <div className="animate-fade-in">
            <div className="p-6 bg-gray-800 rounded-lg mb-6 shadow-lg border border-green-500/30">
                <h2 className="text-xl font-bold mb-1">Welcome, {user.firstName}!</h2>
                <p className="text-gray-400 mb-4">Select an option to get started.</p>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-center">
                    <div className="p-3 bg-gray-900 rounded-md">
                        <p className="text-2xl font-bold text-green-400">{user.diamonds}</p>
                        <p className="text-xs text-gray-400">Diamonds</p>
                    </div>
                    <div className="p-3 bg-gray-900 rounded-md">
                        <p className="text-2xl font-bold">{user.totalBombs}</p>
                        <p className="text-xs text-gray-400">Total Bombs</p>
                    </div>
                     <div className="p-3 bg-gray-900 rounded-md">
                        <p className="text-2xl font-bold">{user.referralCount}</p>
                        <p className="text-xs text-gray-400">Referrals</p>
                    </div>
                     <div className="p-3 bg-gray-900 rounded-md">
                        <p className="text-2xl font-bold">{user.safeList.length}</p>
                        <p className="text-xs text-gray-400">Safe Numbers</p>
                    </div>
                </div>
            </div>
            <div className="grid grid-cols-3 md:grid-cols-5 gap-3">
                <MenuButton icon={<BombIcon className="w-full h-full text-green-400"/>} label="Start Bomb" onClick={() => setView(UserPanelView.Bomb)} />
                <MenuButton icon={<GiftIcon className="w-full h-full text-green-400"/>} label="Redeem Code" onClick={() => setView(UserPanelView.Redeem)} />
                <MenuButton icon={<UserGroupIcon className="w-full h-full text-green-400"/>} label="Referral" onClick={() => setView(UserPanelView.Referral)} />
                <MenuButton icon={<ShieldCheckIcon className="w-full h-full text-green-400"/>} label="Safe List" onClick={() => setView(UserPanelView.SafeList)} />
                <MenuButton icon={<TrophyIcon className="w-full h-full text-green-400"/>} label="Leaderboard" onClick={() => setView(UserPanelView.Leaderboard)} />
                <MenuButton icon={<UserCircleIcon className="w-full h-full text-green-400"/>} label="My Profile" onClick={() => setView(UserPanelView.Profile)} />
                <MenuButton icon={<InfoIcon className="w-full h-full text-green-400"/>} label="Help" onClick={() => setView(UserPanelView.Help)} />
                <MenuButton icon={<KeyIcon className="w-full h-full text-green-400"/>} label="API Status" onClick={() => setView(UserPanelView.ApiStatus)} />
            </div>
        </div>
    );
};

const BombView: React.FC<{ user: User, showToast: UserPanelProps['showToast'], refreshUser: () => void, setView: (v: UserPanelView) => void }> = ({ user, showToast, refreshUser, setView }) => {
    const [step, setStep] = useState(1);
    const [target, setTarget] = useState('');
    const [amount, setAmount] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [geminiPrompt, setGeminiPrompt] = useState('');
    const [generatedMessage, setGeneratedMessage] = useState('');
    const [isGenerating, setIsGenerating] = useState(false);

    const handleTargetSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (/^01[3-9]\d{8}$/.test(target)) {
            setStep(2);
        } else {
            showToast('Invalid Bangladeshi number format (e.g., 017xxxxxxxx).', 'error');
        }
    };

    const handleAmountSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        const numAmount = parseInt(amount, 10);
        if (isNaN(numAmount) || numAmount <= 0 || numAmount > 100) {
            showToast('Amount must be a number between 1 and 100.', 'error');
            return;
        }

        setIsLoading(true);
        try {
            const res = await api.sendSmsBomb(user.id, target, numAmount);
            if(res.success) {
                showToast(res.message, 'success');
                refreshUser();
                setTarget('');
                setAmount('');
                setStep(1);
            } else {
                showToast(res.message, 'error');
            }
        } catch (error) {
            showToast('An error occurred during the attack.', 'error');
        } finally {
            setIsLoading(false);
        }
    };

    const handleGenerateMessage = async () => {
        if (!geminiPrompt) {
            showToast("Please enter a theme for the message.", "info");
            return;
        }
        setIsGenerating(true);
        setGeneratedMessage('');
        const message = await geminiService.generateCreativeMessage(geminiPrompt);
        setGeneratedMessage(message);
        setIsGenerating(false);
    };

    return (
        <div className="max-w-md mx-auto bg-gray-800 p-6 rounded-lg animate-fade-in">
            <h2 className="text-2xl font-bold mb-4 text-green-400">Start Attack</h2>
            {step === 1 && (
                <form onSubmit={handleTargetSubmit}>
                    <label htmlFor="target" className="block text-sm font-medium text-gray-300 mb-2">Step 1: Target Number</label>
                    <input type="tel" id="target" value={target} onChange={e => setTarget(e.target.value)} placeholder="017xxxxxxxx" className="w-full bg-gray-900 border border-gray-700 rounded-md px-3 py-2 focus:ring-green-500 focus:border-green-500" required />
                    <button type="submit" className="w-full bg-green-500 hover:bg-green-600 text-white font-bold py-2 px-4 rounded-md mt-4 transition-colors">Next</button>
                </form>
            )}
            {step === 2 && (
                <form onSubmit={handleAmountSubmit}>
                    <p className="text-gray-400 mb-2">Target: <code className="bg-gray-700 p-1 rounded">{target}</code></p>
                    <label htmlFor="amount" className="block text-sm font-medium text-gray-300 mb-2">Step 2: Amount (Max 100)</label>
                    <input type="number" id="amount" value={amount} onChange={e => setAmount(e.target.value)} min="1" max="100" placeholder="e.g., 50" className="w-full bg-gray-900 border border-gray-700 rounded-md px-3 py-2 focus:ring-green-500 focus:border-green-500" required />
                    <p className="text-sm text-gray-400 mt-2">Cost: {parseInt(amount) || 0} Diamonds</p>
                     <div className="flex items-center gap-2 mt-4">
                        <button type="submit" disabled={isLoading} className="w-full bg-red-600 hover:bg-red-700 text-white font-bold py-2 px-4 rounded-md transition-colors disabled:bg-red-800 disabled:cursor-not-allowed">
                            {isLoading ? 'Attacking...' : 'Launch Attack'}
                        </button>
                         <button type="button" onClick={() => setIsModalOpen(true)} className="p-2 bg-blue-500 hover:bg-blue-600 rounded-md" title="Generate Creative Message">
                            <SparklesIcon className="w-6 h-6" />
                        </button>
                    </div>
                    <button type="button" onClick={() => setStep(1)} className="w-full text-gray-400 hover:text-white py-2 mt-2">Back</button>
                </form>
            )}
            {isModalOpen && (
                <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50 p-4">
                    <div className="bg-gray-800 rounded-lg p-6 w-full max-w-md relative animate-fade-in">
                        <button onClick={() => setIsModalOpen(false)} className="absolute top-2 right-2 p-1 text-gray-400 hover:text-white"><CloseIcon className="w-6 h-6"/></button>
                        <h3 className="text-lg font-bold mb-4 text-blue-400">Creative Message Generator</h3>
                        <input type="text" value={geminiPrompt} onChange={e => setGeminiPrompt(e.target.value)} placeholder="Enter a theme, e.g., 'cat facts'" className="w-full bg-gray-900 border border-gray-700 rounded-md px-3 py-2 mb-3" />
                        <button onClick={handleGenerateMessage} disabled={isGenerating} className="w-full bg-blue-500 hover:bg-blue-600 font-bold py-2 rounded-md disabled:bg-blue-800">
                            {isGenerating ? 'Generating...' : 'Generate with AI'}
                        </button>
                        {generatedMessage && (
                            <div className="mt-4 p-3 bg-gray-900 rounded-md">
                                <p className="text-gray-300">{generatedMessage}</p>
                                <button onClick={() => {navigator.clipboard.writeText(generatedMessage); showToast('Copied to clipboard!', 'success');}} className="text-blue-400 text-sm mt-2">Copy</button>
                            </div>
                        )}
                    </div>
                </div>
            )}
             <button onClick={() => setView(UserPanelView.Dashboard)} className="w-full text-gray-400 hover:text-white py-2 mt-4 text-sm">Back to Dashboard</button>
        </div>
    );
};

const SafeListView: React.FC<{ user: User, showToast: UserPanelProps['showToast'], refreshUser: () => void, setView: (v: UserPanelView) => void }> = ({ user, showToast, refreshUser, setView }) => {
    const [phone, setPhone] = useState('');
    const [isLoading, setIsLoading] = useState(false);

    const handleAdd = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!/^01[3-9]\d{8}$/.test(phone)) {
            showToast('Invalid Bangladeshi number format.', 'error');
            return;
        }
        setIsLoading(true);
        try {
            await api.addToSafeList(user.id, phone);
            showToast('Number added to your safe list.', 'success');
            refreshUser();
            setPhone('');
        } catch (error) {
            showToast('Failed to add number.', 'error');
        } finally {
            setIsLoading(false);
        }
    };
    
    const handleRemove = async (phoneToRemove: string) => {
        try {
            await api.removeFromSafeList(user.id, phoneToRemove);
            showToast('Number removed from your safe list.', 'success');
            refreshUser();
        } catch (error) {
            showToast('Failed to remove number.', 'error');
        }
    };

    return (
        <div className="max-w-md mx-auto bg-gray-800 p-6 rounded-lg animate-fade-in">
             <h2 className="text-2xl font-bold mb-4 text-green-400">My Safe List</h2>
             <p className="text-gray-400 mb-4 text-sm">Numbers on this list cannot be targeted by any user of this service. Add your personal numbers to protect them.</p>
             <form onSubmit={handleAdd} className="flex gap-2 mb-4">
                 <input type="tel" value={phone} onChange={e => setPhone(e.target.value)} placeholder="01xxxxxxxxx" className="flex-grow bg-gray-900 border border-gray-700 rounded-md px-3 py-2" required />
                 <button type="submit" disabled={isLoading} className="bg-green-500 hover:bg-green-600 text-white font-bold py-2 px-4 rounded-md disabled:bg-green-800">Add</button>
             </form>
             <div className="space-y-2">
                 {user.safeList.length > 0 ? user.safeList.map(p => (
                     <div key={p} className="flex justify-between items-center bg-gray-900 p-3 rounded-md">
                         <code>{p}</code>
                         <button onClick={() => handleRemove(p)} className="text-red-500 hover:text-red-400"><TrashIcon className="w-5 h-5" /></button>
                     </div>
                 )) : <p className="text-gray-500 text-center">Your safe list is empty.</p>}
             </div>
             <button onClick={() => setView(UserPanelView.Dashboard)} className="w-full text-gray-400 hover:text-white py-2 mt-4 text-sm">Back to Dashboard</button>
        </div>
    );
};

const ProfileView: React.FC<{ user: User, setView: (v: UserPanelView) => void }> = ({ user, setView }) => {
    return (
        <div className="max-w-md mx-auto bg-gray-800 p-6 rounded-lg animate-fade-in">
             <h2 className="text-2xl font-bold mb-4 text-green-400">My Profile</h2>
             <div className="space-y-3">
                <div className="flex justify-between"><span className="text-gray-400">User ID:</span> <code>{user.id}</code></div>
                <div className="flex justify-between"><span className="text-gray-400">Name:</span> <span>{user.firstName}</span></div>
                <div className="flex justify-between"><span className="text-gray-400">Joined:</span> <span>{new Date(user.joinedDate).toLocaleDateString()}</span></div>
                <hr className="border-gray-700"/>
                <div className="flex justify-between"><span className="text-gray-400">Diamonds:</span> <span className="text-green-400 font-bold">{user.diamonds} 💎</span></div>
                <div className="flex justify-between"><span className="text-gray-400">Total Bombs:</span> <span>{user.totalBombs} 💣</span></div>
                <div className="flex justify-between"><span className="text-gray-400">Referrals:</span> <span>{user.referralCount} 👥</span></div>
             </div>
             <button onClick={() => setView(UserPanelView.Dashboard)} className="w-full text-gray-400 hover:text-white py-2 mt-6 text-sm">Back to Dashboard</button>
        </div>
    );
};

// --- Main User Panel Component ---

const UserPanel: React.FC<UserPanelProps> = ({ user, showToast, refreshUser }) => {
    const [view, setView] = useState<UserPanelView>(UserPanelView.Dashboard);
    const [dailyBonusLoading, setDailyBonusLoading] = useState(false);

    const handleDailyBonus = async () => {
        setDailyBonusLoading(true);
        try {
            const res = await api.claimDailyBonus(user.id);
            showToast(`You claimed ${res.amount} diamonds!`, 'success');
            refreshUser();
        } catch (error: any) {
            showToast(error.message || 'Failed to claim bonus.', 'error');
        } finally {
            setDailyBonusLoading(false);
        }
    };
    
    const renderView = () => {
        switch (view) {
            case UserPanelView.Bomb:
                return <BombView user={user} showToast={showToast} refreshUser={refreshUser} setView={setView} />;
            case UserPanelView.SafeList:
                return <SafeListView user={user} showToast={showToast} refreshUser={refreshUser} setView={setView} />;
             case UserPanelView.Profile:
                return <ProfileView user={user} setView={setView}/>;
            case UserPanelView.Dashboard:
            default:
                return <DashboardView user={user} setView={setView} />;
        }
    };

    return (
        <div>
            {view === UserPanelView.Dashboard && (
                <button 
                    onClick={handleDailyBonus} 
                    disabled={dailyBonusLoading}
                    className="w-full mb-6 p-4 bg-yellow-500 text-gray-900 font-bold rounded-lg flex items-center justify-center gap-2 hover:bg-yellow-400 transition-colors disabled:bg-yellow-700 disabled:cursor-not-allowed"
                >
                    <DiamondIcon className="w-6 h-6"/>
                    {dailyBonusLoading ? 'Claiming...' : 'Claim Daily Bonus (200 💎)'}
                </button>
            )}
            {renderView()}
        </div>
    );
};

export default UserPanel;
