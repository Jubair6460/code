
import React, { useEffect, useState } from 'react';
import { CloseIcon } from '../icons';

interface ToastProps {
  message: string;
  type: 'success' | 'error' | 'info';
  onClose: () => void;
}

export const Toast: React.FC<ToastProps> = ({ message, type, onClose }) => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    setVisible(true);
    const timer = setTimeout(() => {
      handleClose();
    }, 3000);
    return () => clearTimeout(timer);
  }, [message]);

  const handleClose = () => {
    setVisible(false);
    setTimeout(onClose, 300); // Allow for exit animation
  };

  const baseClasses = "fixed top-5 right-5 z-50 flex items-center p-4 rounded-lg shadow-lg text-white max-w-xs transition-all duration-300";
  const typeClasses = {
    success: 'bg-green-500',
    error: 'bg-red-500',
    info: 'bg-blue-500',
  };
  const visibilityClass = visible ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-full';

  return (
    <div className={`${baseClasses} ${typeClasses[type]} ${visibilityClass}`}>
      <div className="flex-grow">{message}</div>
      <button onClick={handleClose} className="ml-4 -mr-2 p-1 rounded-md hover:bg-white/20 focus:outline-none">
        <CloseIcon className="w-5 h-5" />
      </button>
    </div>
  );
};
