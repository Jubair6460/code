
import React, { useState, useEffect } from 'react';
import { User, AdminPanelView, ToastMessage, SystemStats, RedeemCode } from '../types';
import { api } from '../services/api';

interface AdminPanelProps {
  user: User;
  showToast: (message: string, type: ToastMessage['type']) => void;
}

const AdminPanel: React.FC<AdminPanelProps> = ({ user, showToast }) => {
    const [view, setView] = useState<AdminPanelView>(AdminPanelView.Dashboard);
    const [stats, setStats] = useState<SystemStats | null>(null);
    const [users, setUsers] = useState<User[]>([]);
    const [selectedUser, setSelectedUser] = useState<User | null>(null);
    const [blacklist, setBlacklist] = useState<string[]>([]);
    const [codes, setCodes] = useState<RedeemCode[]>([]);
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        const fetchData = async () => {
            setIsLoading(true);
            try {
                const allUsers = await api.getAllUsers();
                setUsers(allUsers);
                
                const fetchedBlacklist = await api.getBlacklist();
                setBlacklist(fetchedBlacklist);

                const fetchedCodes = await api.getAllCodes();
                setCodes(fetchedCodes);

                // Mock stats calculation
                const totalBombs = allUsers.reduce((sum, u) => sum + u.totalBombs, 0);
                const totalDiamonds = allUsers.reduce((sum, u) => sum + u.diamonds, 0);
                const bannedUsers = allUsers.filter(u => u.isBlocked).length;
                setStats({
                    users: allUsers.length,
                    activeToday: allUsers.filter(u => new Date(u.lastActive) > new Date(Date.now() - 86400000)).length,
                    bombs: totalBombs,
                    diamonds: totalDiamonds,
                    bannedUsers: bannedUsers,
                    blacklistedNumbers: fetchedBlacklist.length,
                    recentBombs24h: 0, // Mocked
                });

            } catch (error) {
                showToast('Failed to load admin data.', 'error');
            } finally {
                setIsLoading(false);
            }
        };

        fetchData();
    }, []);
    
    const handleUserUpdate = async (updatedUser: User) => {
        try {
            await api.updateUser(updatedUser);
            setUsers(users.map(u => u.id === updatedUser.id ? updatedUser : u));
            setSelectedUser(updatedUser);
            showToast("User updated successfully", "success");
        } catch {
            showToast("Failed to update user", "error");
        }
    };
    
    const handleBlacklistAdd = async (phone: string) => {
        try {
            const newList = await api.addToBlacklist(phone);
            setBlacklist(newList);
            showToast("Number added to blacklist", "success");
        } catch {
            showToast("Failed to add to blacklist", "error");
        }
    };
    
    const handleBlacklistRemove = async (phone: string) => {
        try {
            const newList = await api.removeFromBlacklist(phone);
            setBlacklist(newList);
            showToast("Number removed from blacklist", "success");
        } catch {
            showToast("Failed to remove from blacklist", "error");
        }
    };


    const renderView = () => {
        if(isLoading) return <div className="text-center p-8">Loading Admin Data...</div>

        switch(view) {
            case AdminPanelView.UserManagement:
                return <UserManagementView users={users} selectedUser={selectedUser} setSelectedUser={setSelectedUser} onUpdateUser={handleUserUpdate} setView={setView} />;
            case AdminPanelView.Blacklist:
                 return <BlacklistView blacklist={blacklist} onAdd={handleBlacklistAdd} onRemove={handleBlacklistRemove} setView={setView} />;
            case AdminPanelView.Dashboard:
            default:
                return <DashboardView stats={stats} setView={setView} />;
        }
    }

    return (
        <div className="bg-gray-800 rounded-lg p-4 md:p-6 shadow-lg border border-red-500/30">
            {renderView()}
        </div>
    );
};

const DashboardView: React.FC<{stats: SystemStats | null, setView: (v: AdminPanelView) => void}> = ({ stats, setView }) => (
    <div className="animate-fade-in">
        <h2 className="text-2xl font-bold text-red-400 mb-4">Admin Dashboard</h2>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mb-6">
            {stats && Object.entries(stats).map(([key, value]) => (
                <div key={key} className="bg-gray-900 p-4 rounded-lg">
                    <p className="text-3xl font-bold">{value}</p>
                    <p className="text-sm text-gray-400 capitalize">{key.replace(/([A-Z])/g, ' $1').trim()}</p>
                </div>
            ))}
        </div>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            <button onClick={() => setView(AdminPanelView.UserManagement)} className="p-4 bg-gray-700 rounded-lg hover:bg-red-500 transition-colors">User Management</button>
            <button onClick={() => setView(AdminPanelView.Blacklist)} className="p-4 bg-gray-700 rounded-lg hover:bg-red-500 transition-colors">Blacklist</button>
             <button disabled className="p-4 bg-gray-700 rounded-lg cursor-not-allowed opacity-50">Broadcast</button>
            <button disabled className="p-4 bg-gray-700 rounded-lg cursor-not-allowed opacity-50">Settings</button>
        </div>
    </div>
);

const UserManagementView: React.FC<{
    users: User[],
    selectedUser: User | null,
    setSelectedUser: (u: User | null) => void,
    onUpdateUser: (u: User) => void,
    setView: (v: AdminPanelView) => void
}> = ({ users, selectedUser, setSelectedUser, onUpdateUser, setView }) => {
    const [searchTerm, setSearchTerm] = useState('');

    const filteredUsers = users.filter(u => u.username.includes(searchTerm.toLowerCase()) || String(u.id).includes(searchTerm));

    return (
        <div className="animate-fade-in">
            <h2 className="text-2xl font-bold text-red-400 mb-4">User Management</h2>
            <div className="grid md:grid-cols-3 gap-6">
                <div className="md:col-span-1">
                    <input type="text" placeholder="Search by ID or Username" value={searchTerm} onChange={e => setSearchTerm(e.target.value)} className="w-full bg-gray-900 p-2 rounded-md mb-2" />
                    <ul className="h-96 overflow-y-auto bg-gray-900 rounded-md p-2 space-y-1">
                        {filteredUsers.map(u => (
                            <li key={u.id} onClick={() => setSelectedUser(u)} className={`p-2 rounded cursor-pointer flex justify-between ${selectedUser?.id === u.id ? 'bg-red-500' : 'hover:bg-gray-700'}`}>
                                <span>{u.firstName} ({u.id})</span>
                                {u.isBlocked && <span className="text-xs text-red-400">Banned</span>}
                            </li>
                        ))}
                    </ul>
                </div>
                <div className="md:col-span-2 bg-gray-900 p-4 rounded-md">
                    {selectedUser ? (
                        <div>
                            <h3 className="text-xl font-bold">{selectedUser.firstName} <span className="text-gray-400">#{selectedUser.id}</span></h3>
                            <p className="text-gray-400 mb-4">@{selectedUser.username}</p>
                            <div className="grid grid-cols-2 gap-4 mb-4">
                                <div><span className="text-gray-400">Diamonds:</span> {selectedUser.diamonds}</div>
                                <div><span className="text-gray-400">Bombs:</span> {selectedUser.totalBombs}</div>
                                <div><span className="text-gray-400">Referrals:</span> {selectedUser.referralCount}</div>
                                <div><span className="text-gray-400">Status:</span> {selectedUser.isBlocked ? 'Banned' : 'Active'}</div>
                            </div>
                            <div className="flex gap-2">
                                <button onClick={() => onUpdateUser({...selectedUser, isBlocked: !selectedUser.isBlocked})} className={`w-full p-2 rounded ${selectedUser.isBlocked ? 'bg-green-500' : 'bg-red-500'}`}>{selectedUser.isBlocked ? 'Unban' : 'Ban'} User</button>
                            </div>
                        </div>
                    ) : <p className="text-center text-gray-500">Select a user to view details</p>}
                </div>
            </div>
            <button onClick={() => setView(AdminPanelView.Dashboard)} className="text-gray-400 hover:text-white py-2 mt-4 text-sm">Back to Dashboard</button>
        </div>
    );
};

const BlacklistView: React.FC<{
    blacklist: string[],
    onAdd: (phone: string) => void,
    onRemove: (phone: string) => void,
    setView: (v: AdminPanelView) => void
}> = ({ blacklist, onAdd, onRemove, setView }) => {
    const [newPhone, setNewPhone] = useState('');

    const handleAddSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (/^01[3-9]\d{8}$/.test(newPhone)) {
            onAdd(newPhone);
            setNewPhone('');
        } else {
            alert("Invalid number format");
        }
    };
    
    return (
         <div className="animate-fade-in">
            <h2 className="text-2xl font-bold text-red-400 mb-4">Blacklist Management</h2>
            <form onSubmit={handleAddSubmit} className="flex gap-2 mb-4">
                <input type="tel" value={newPhone} onChange={e => setNewPhone(e.target.value)} placeholder="01xxxxxxxxx" className="flex-grow bg-gray-900 p-2 rounded-md" required />
                <button type="submit" className="bg-red-500 hover:bg-red-600 text-white font-bold py-2 px-4 rounded-md">Add</button>
            </form>
            <ul className="h-80 overflow-y-auto bg-gray-900 rounded-md p-2 space-y-1">
                {blacklist.map(phone => (
                    <li key={phone} className="p-2 rounded flex justify-between items-center bg-gray-800">
                        <code>{phone}</code>
                        <button onClick={() => onRemove(phone)} className="text-red-400 hover:text-red-300">Remove</button>
                    </li>
                ))}
            </ul>
            <button onClick={() => setView(AdminPanelView.Dashboard)} className="text-gray-400 hover:text-white py-2 mt-4 text-sm">Back to Dashboard</button>
        </div>
    )
};


export default AdminPanel;
