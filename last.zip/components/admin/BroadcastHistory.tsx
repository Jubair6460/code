import React, { useState, useEffect } from 'react';
import { api } from '../../services/mockApiService';
import { BroadcastLog } from '../../types';
import { styleText } from '../../constants';

const BroadcastHistory: React.FC = () => {
    const [history, setHistory] = useState<BroadcastLog[]>([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchHistory = async () => {
            setLoading(true);
            const data = await api.getBroadcastHistory();
            setHistory(data);
            setLoading(false);
        };
        fetchHistory();
    }, []);

    if (loading) {
        return <div className="flex justify-center items-center h-full"><div className="w-12 h-12 border-4 border-t-transparent border-blue-500 rounded-full animate-spin"></div></div>;
    }

    return (
        <div>
            <h1 className="text-2xl font-bold text-white mb-6">{styleText('Broadcast History')}</h1>

            <div className="space-y-4">
                {history.length > 0 ? history.map(log => (
                    <div key={log.id} className="bg-gray-700/50 p-4 rounded-xl">
                        <p className="text-gray-200 mb-2">"{log.message}"</p>
                        <div className="text-xs text-gray-400 flex justify-between items-center">
                            <span>Sent by Admin ID {log.adminId} on {new Date(log.sentAt).toLocaleString()}</span>
                            <span>
                                <span className="text-green-400">Success: {log.stats.success}</span> | <span className="text-red-400">Failed: {log.stats.failed}</span>
                            </span>
                        </div>
                    </div>
                )) : (
                    <p className="text-center text-gray-400 py-8">No broadcast history found.</p>
                )}
            </div>
        </div>
    );
};

export default BroadcastHistory;
