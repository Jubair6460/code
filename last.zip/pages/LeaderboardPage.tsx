import React, { useState, useEffect } from 'react';
import { api } from '../services/mockApiService';
import { User } from '../types';
import { styleText } from '../constants';

type LeaderboardType = 'diamonds' | 'referrals' | 'smss';

const LeaderboardPage: React.FC = () => {
    const [leaderboardType, setLeaderboardType] = useState<LeaderboardType>('smss');
    const [users, setUsers] = useState<User[]>([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchLeaderboard = async () => {
            setLoading(true);
            const data = await api.getLeaderboard(leaderboardType, 20);
            setUsers(data);
            setLoading(false);
        };
        fetchLeaderboard();
    }, [leaderboardType]);
    
    const getMedal = (index: number) => {
        if (index === 0) return '🥇';
        if (index === 1) return '🥈';
        if (index === 2) return '🥉';
        return `${index + 1}.`;
    };

    const renderValue = (user: User) => {
        switch (leaderboardType) {
            case 'diamonds': return `💎 ${user.diamonds.toLocaleString()}`;
            case 'referrals': return `👥 ${user.referralCount.toLocaleString()}`;
            case 'smss': return `💣 ${user.totalSmss.toLocaleString()}`;
        }
    };
    
    const getTabClass = (type: LeaderboardType) => {
      return `w-full py-2 text-sm font-semibold rounded-md transition-all duration-300 ${leaderboardType === type ? 'bg-blue-600 text-white shadow' : 'text-gray-300 hover:bg-gray-700/50'}`;
    };

    return (
        <div className="max-w-4xl mx-auto py-6 sm:px-6 lg:px-8">
            <h1 className="text-3xl font-bold text-white mb-6 px-4 sm:px-0 text-center">{styleText('🏆 Leaderboards')}</h1>
            
            <div className="bg-gray-800 shadow-xl rounded-2xl p-4 md:p-6">
                <div className="flex justify-center bg-gray-700 p-1 rounded-lg mb-6">
                    <button onClick={() => setLeaderboardType('smss')} className={getTabClass('smss')}>{styleText('Top Bombers')}</button>
                    <button onClick={() => setLeaderboardType('diamonds')} className={getTabClass('diamonds')}>{styleText('Top Richest')}</button>
                    <button onClick={() => setLeaderboardType('referrals')} className={getTabClass('referrals')}>{styleText('Top Referrers')}</button>
                </div>
                
                {loading ? (
                    <div className="flex justify-center items-center h-64">
                         <div className="w-12 h-12 border-4 border-t-transparent border-blue-500 rounded-full animate-spin"></div>
                    </div>
                ) : (
                    <div className="space-y-3">
                        {users.map((user, index) => (
                            <div key={user.id} className="flex items-center bg-gray-700/50 p-3 rounded-lg hover:bg-gray-700 transition-colors">
                                <div className="w-10 text-center font-bold text-lg">{getMedal(index)}</div>
                                <div className="flex-1 font-semibold text-gray-200">{user.firstName}</div>
                                <div className="font-bold text-blue-400">{renderValue(user)}</div>
                            </div>
                        ))}
                    </div>
                )}
            </div>
        </div>
    );
};

export default LeaderboardPage;
