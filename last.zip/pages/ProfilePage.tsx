import React, { useState, useEffect, useCallback } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useToast } from '../contexts/ToastContext';
import { api } from '../services/mockApiService';
import { styleText, REFERRAL_DOMAIN } from '../constants';
import { SafeListItem, Transaction } from '../types';
import { ClipboardIcon, CheckIcon } from '@heroicons/react/24/outline';

const ProfilePage: React.FC = () => {
    const { user, refreshUser } = useAuth();
    const { addToast } = useToast();
    const [transactions, setTransactions] = useState<Transaction[]>([]);
    const [safelist, setSafelist] = useState<SafeListItem[]>([]);
    const [newSafeNumber, setNewSafeNumber] = useState('');
    const [newSafeNote, setNewSafeNote] = useState('');
    const [copied, setCopied] = useState(false);
    
    // State for password change
    const [oldPassword, setOldPassword] = useState('');
    const [newPassword, setNewPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');


    const fetchProfileData = useCallback(async () => {
        if (user) {
            const [userTransactions, userSafelist] = await Promise.all([
                api.getTransactions(user.id, 10),
                api.getSafelist(user.id)
            ]);
            setTransactions(userTransactions);
            setSafelist(userSafelist);
        }
    }, [user]);

    useEffect(() => {
        fetchProfileData();
    }, [fetchProfileData]);

    const handleClaimBonus = async () => {
        if (!user) return;
        const result = await api.claimDailyBonus(user.id);
        if (result.success) {
            addToast(result.message, 'success');
            await refreshUser();
        } else {
            addToast(result.message, 'error');
        }
    };
    
    const handleAddSafelist = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!user) return;
        if (!/^01[3-9]\d{8}$/.test(newSafeNumber)) {
            addToast('Invalid Bangladeshi phone number format.', 'error');
            return;
        }
        const result = await api.addToSafelist(user.id, newSafeNumber, newSafeNote);
        if (result.success) {
            addToast(result.message, 'success');
            setNewSafeNumber('');
            setNewSafeNote('');
            await fetchProfileData();
        } else {
            addToast(result.message, 'error');
        }
    };

    const handleRemoveSafelist = async (phoneNumber: string) => {
        if (!user) return;
        const result = await api.removeFromSafelist(user.id, phoneNumber);
        if (result.success) {
            addToast(result.message, 'info');
            await fetchProfileData();
        } else {
            addToast(result.message, 'error');
        }
    };
    
    const copyReferralLink = () => {
        if(!user) return;
        const link = `https://${REFERRAL_DOMAIN}/#/?ref=${user.referralCode}`;
        navigator.clipboard.writeText(link);
        setCopied(true);
        addToast('Referral link copied to clipboard!', 'success');
        setTimeout(() => setCopied(false), 2000);
    };

    const handleChangePassword = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!user) return;
        if (newPassword !== confirmPassword) {
            addToast("New passwords do not match.", 'error');
            return;
        }
        if (newPassword.length < 6) {
            addToast("Password must be at least 6 characters long.", 'error');
            return;
        }

        const result = await api.changePassword(user.id, oldPassword, newPassword);
        if (result.success) {
            addToast(result.message, 'success');
            setOldPassword('');
            setNewPassword('');
            setConfirmPassword('');
        } else {
            addToast(result.message, 'error');
        }
    };

    if (!user) return null;

    return (
        <div className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
            <h1 className="text-3xl font-bold text-white mb-6 px-4 sm:px-0">{styleText('My Profile')}</h1>
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 px-4 sm:px-0">
                <div className="lg:col-span-2 space-y-8">
                    {/* Change Password */}
                    <div className="bg-gray-800 shadow-xl rounded-2xl p-6">
                        <h2 className="text-xl font-bold text-white mb-4">{styleText('🔑 Change Password')}</h2>
                        <form onSubmit={handleChangePassword} className="space-y-4">
                            <input type="password" value={oldPassword} onChange={e => setOldPassword(e.target.value)} placeholder="Old Password" required className="w-full bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-sm" />
                            <input type="password" value={newPassword} onChange={e => setNewPassword(e.target.value)} placeholder="New Password" required className="w-full bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-sm" />
                            <input type="password" value={confirmPassword} onChange={e => setConfirmPassword(e.target.value)} placeholder="Confirm New Password" required className="w-full bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-sm" />
                            <button type="submit" className="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-4 rounded-lg text-sm">{styleText('Update Password')}</button>
                        </form>
                    </div>

                    {/* Safelist Management */}
                    <div className="bg-gray-800 shadow-xl rounded-2xl p-6">
                        <h2 className="text-xl font-bold text-white mb-4">{styleText('🛡️ My Safe List')}</h2>
                        <form onSubmit={handleAddSafelist} className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                            <input type="text" value={newSafeNumber} onChange={e => setNewSafeNumber(e.target.value)} placeholder="Phone Number" className="md:col-span-1 bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-sm" />
                            <input type="text" value={newSafeNote} onChange={e => setNewSafeNote(e.target.value)} placeholder="Note (e.g., Mom)" className="md:col-span-1 bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-sm" />
                            <button type="submit" className="md:col-span-1 bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-4 rounded-lg text-sm">{styleText('Add Number')}</button>
                        </form>
                        <div className="max-h-60 overflow-y-auto pr-2 space-y-2">
                            {safelist.length > 0 ? safelist.map(item => (
                                <div key={item.phoneNumber} className="flex justify-between items-center bg-gray-700/50 p-3 rounded-lg">
                                    <div>
                                        <p className="font-mono text-gray-200">{item.phoneNumber}</p>
                                        <p className="text-xs text-gray-400">{item.note || 'No note'}</p>
                                    </div>
                                    <button onClick={() => handleRemoveSafelist(item.phoneNumber)} className="text-red-400 hover:text-red-300 text-xs font-semibold">{styleText('REMOVE')}</button>
                                </div>
                            )) : <p className="text-gray-400 text-center">{styleText('Your safelist is empty.')}</p>}
                        </div>
                    </div>
                </div>

                <div className="space-y-8">
                     {/* User Stats */}
                    <div className="bg-gray-800 shadow-xl rounded-2xl p-6">
                        <h2 className="text-xl font-bold text-white mb-4 text-center">{user.firstName}</h2>
                        <div className="space-y-3 text-gray-300">
                           <p className="flex justify-between"><span>{styleText('User ID:')}</span> <code className="bg-gray-700 p-1 rounded text-xs">{user.id}</code></p>
                           <p className="flex justify-between"><span>{styleText('Joined:')}</span> <span>{new Date(user.joinedDate).toLocaleDateString()}</span></p>
                           <hr className="border-gray-700" />
                           <p className="flex justify-between"><span>💎 {styleText('Diamonds:')}</span> <span className="font-bold text-white">{user.diamonds.toLocaleString()}</span></p>
                           <p className="flex justify-between"><span>💣 {styleText('Total SMS:')}</span> <span className="font-bold text-white">{user.totalSmss.toLocaleString()}</span></p>
                           <p className="flex justify-between"><span>👥 {styleText('Referrals:')}</span> <span className="font-bold text-white">{user.referralCount}</span></p>
                        </div>
                         <button onClick={handleClaimBonus} className="w-full mt-6 bg-green-600 hover:bg-green-700 text-white font-semibold py-2 px-4 rounded-lg">{styleText('🎁 Claim Daily Bonus')}</button>
                    </div>

                    {/* Referral Program */}
                    <div className="bg-gray-800 shadow-xl rounded-2xl p-6">
                        <h2 className="text-xl font-bold text-white mb-4">{styleText('👥 Referral Program')}</h2>
                        <p className="text-gray-400 text-sm mb-4">{styleText('Share your code and earn diamonds!')}</p>
                        <div className="bg-gray-700 p-3 rounded-lg flex items-center justify-between">
                            <code className="text-blue-300 text-sm">{user.referralCode}</code>
                            <button onClick={copyReferralLink} className="ml-4">
                                {copied ? <CheckIcon className="h-5 w-5 text-green-400"/> : <ClipboardIcon className="h-5 w-5 text-gray-400 hover:text-white"/>}
                            </button>
                        </div>
                    </div>

                     {/* Transaction History */}
                    <div className="bg-gray-800 shadow-xl rounded-2xl p-6">
                        <h2 className="text-xl font-bold text-white mb-4">{styleText('📜 Recent Activity')}</h2>
                        <div className="space-y-3 max-h-80 overflow-y-auto pr-2">
                        {transactions.length > 0 ? transactions.map(tx => (
                            <div key={tx.id} className="flex justify-between items-center text-sm">
                                <div>
                                    <p className="font-semibold text-gray-200">{tx.reason.replace(/_/g, ' ').toUpperCase()}</p>
                                    <p className="text-gray-400">{new Date(tx.timestamp).toLocaleString()}</p>
                                </div>
                                <p className={`font-bold ${tx.amount > 0 ? 'text-green-400' : 'text-red-400'}`}>
                                    {tx.amount > 0 ? '+' : ''}{tx.amount.toLocaleString()} 💎
                                </p>
                            </div>
                        )) : <p className="text-gray-400 text-center">{styleText('No recent transactions.')}</p>}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default ProfilePage;