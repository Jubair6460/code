import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useToast } from '../contexts/ToastContext';
import { api } from '../services/mockApiService';
import { styleText } from '../constants';
import { SmsLog, SystemSettings } from '../types';
import { CheckCircleIcon, XCircleIcon, ClockIcon } from '@heroicons/react/24/solid';

const DashboardPage: React.FC = () => {
  const { user, refreshUser } = useAuth();
  const { addToast } = useToast();
  const [target, setTarget] = useState('');
  const [amount, setAmount] = useState('');
  const [loading, setLoading] = useState(false);
  const [cost, setCost] = useState(0);
  const [history, setHistory] = useState<SmsLog[]>([]);
  const [settings, setSettings] = useState<SystemSettings | null>(null);
  const [attackStatus, setAttackStatus] = useState<SmsLog | null>(null);

  useEffect(() => {
    const fetchInitialData = async () => {
        if(user) {
            const userHistory = await api.getUserHistory(user.id, 5);
            setHistory(userHistory);
            const appSettings = await api.getSettings();
            setSettings(appSettings);
        }
    };
    fetchInitialData();
  }, [user]);

  useEffect(() => {
    if (settings) {
      const parsedAmount = parseInt(amount) || 0;
      setCost(parsedAmount * settings.smsCost);
    }
  }, [amount, settings]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !settings) return;
    
    setAttackStatus(null);

    const parsedAmount = parseInt(amount);
    if (isNaN(parsedAmount) || parsedAmount <= 0) {
      addToast('Please enter a valid amount.', 'error');
      return;
    }
    
    if (parsedAmount > settings.maxSmsAmount) {
      addToast(`Maximum amount is ${settings.maxSmsAmount}.`, 'error');
      return;
    }
    
    if (!/^01[3-9]\d{8}$/.test(target)) {
        addToast('Invalid Bangladeshi phone number format (e.g., 017XXXXXXXX).', 'error');
        return;
    }

    if (user.diamonds < cost) {
      addToast('Insufficient diamonds.', 'error');
      return;
    }
    
    setLoading(true);
    const result = await api.sendSms(user.id, target, parsedAmount, (updatedLog) => {
        setAttackStatus(updatedLog);
    });
    setLoading(false);

    if (result.success && result.log) {
      addToast(`Attack on ${target} for ${amount} SMS started successfully!`, 'success');
      setTarget('');
      setAmount('');
      await refreshUser();
      const userHistory = await api.getUserHistory(user.id, 5);
      setHistory([result.log, ...userHistory.slice(0, 4)]);
    } else {
      addToast(result.message, 'error');
    }
  };
  
  const StatusIcon = ({ status, className = "h-5 w-5" }: { status: SmsLog['status'], className?: string }) => {
    if (status === 'completed') return <CheckCircleIcon className={`${className} text-green-500`} />;
    if (status === 'failed') return <XCircleIcon className={`${className} text-red-500`} />;
    return <ClockIcon className={`${className} text-yellow-500`} />;
  };

  return (
    <div className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
      <div className="px-4 py-6 sm:px-0">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          
          <div className="lg:col-span-2">
            <div className="bg-gray-800 shadow-xl rounded-2xl p-6 md:p-8">
              <h1 className="text-3xl font-bold text-white mb-2">{styleText('INITIATE ATTACK')}</h1>
              <p className="text-gray-400 mb-6">{styleText('Enter target details below to start')}</p>
              
              <form onSubmit={handleSubmit} className="space-y-6">
                <div>
                  <label htmlFor="phone" className="block text-sm font-medium text-gray-300 mb-1">{styleText('Target Number')}</label>
                  <input 
                    type="tel" 
                    id="phone"
                    value={target}
                    onChange={e => setTarget(e.target.value)}
                    placeholder="017XXXXXXXX"
                    className="w-full px-4 py-3 bg-gray-700 border border-gray-600 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label htmlFor="amount" className="block text-sm font-medium text-gray-300 mb-1">{styleText('SMS Amount')}</label>
                  <input 
                    type="number" 
                    id="amount"
                    value={amount}
                    onChange={e => setAmount(e.target.value)}
                    placeholder={`Max ${settings?.maxSmsAmount || 200}`}
                    className="w-full px-4 py-3 bg-gray-700 border border-gray-600 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                
                <button
                  type="submit"
                  disabled={loading}
                  className="w-full py-3 font-semibold text-white bg-blue-600 rounded-lg hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 focus:ring-offset-gray-800 disabled:bg-gray-500 disabled:cursor-not-allowed transition-all duration-300 flex items-center justify-center"
                >
                  {loading ? <div className="w-6 h-6 border-2 border-t-transparent border-white rounded-full animate-spin"></div> : `🚀 ${styleText('LAUNCH ATTACK')}`}
                </button>
              </form>
            </div>
            
            {attackStatus && (
                 <div className="mt-8 bg-gray-800 shadow-xl rounded-2xl p-6">
                     <h2 className="text-xl font-bold text-white mb-4">{styleText('Live Attack Status')}</h2>
                     <div className="flex items-center gap-4 bg-gray-700/50 p-4 rounded-lg">
                        <StatusIcon status={attackStatus.status} className="h-8 w-8 flex-shrink-0" />
                        <div>
                            <p className="font-semibold text-white">Target: <span className="font-mono">{attackStatus.targetNumber}</span></p>
                            <p className="text-sm text-gray-300">
                                Status: <span className="font-semibold capitalize">{attackStatus.status}...</span>
                            </p>
                        </div>
                     </div>
                 </div>
            )}
          </div>
          
          <div>
            <div className="bg-gray-800 shadow-xl rounded-2xl p-6 mb-6">
              <h2 className="text-xl font-bold text-white mb-4">{styleText('Attack Summary')}</h2>
              <div className="space-y-3 text-gray-300">
                <div className="flex justify-between"><span>{styleText('Your Diamonds:')}</span> <span className="font-semibold text-white">💎 {user?.diamonds.toLocaleString()}</span></div>
                <div className="flex justify-between"><span>{styleText('SMS Amount:')}</span> <span className="font-semibold text-white">{parseInt(amount) || 0}</span></div>
                <div className="flex justify-between"><span>{styleText('Cost per SMS:')}</span> <span className="font-semibold text-white">💎 {settings?.smsCost || 0}</span></div>
                <hr className="border-gray-700" />
                <div className="flex justify-between text-lg">
                  <span className="font-bold">{styleText('Total Cost:')}</span> 
                  <span className="font-bold text-blue-400">💎 {cost.toLocaleString()}</span>
                </div>
              </div>
            </div>
            
            <div className="bg-gray-800 shadow-xl rounded-2xl p-6">
              <h2 className="text-xl font-bold text-white mb-4">{styleText('Recent History')}</h2>
              <div className="space-y-4">
                {history.length > 0 ? history.map(log => (
                  <div key={log.id} className="flex items-center justify-between text-sm">
                    <div className="flex items-center gap-2">
                        <StatusIcon status={log.status} />
                        <div>
                            <p className="font-semibold text-gray-200">{log.targetNumber}</p>
                            <p className="text-gray-400">{new Date(log.timestamp).toLocaleString()}</p>
                        </div>
                    </div>
                    <div className="text-right">
                       <p className="font-semibold text-gray-200">{log.amount} SMS</p>
                       <p className="text-red-400">- {log.cost} 💎</p>
                    </div>
                  </div>
                )) : (
                    <p className="text-gray-400 text-center py-4">{styleText('No recent attacks found.')}</p>
                )}
              </div>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
};

export default DashboardPage;