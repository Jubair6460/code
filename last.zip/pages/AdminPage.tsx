import React from 'react';
import { Routes, Route, NavLink } from 'react-router-dom';
import AdminDashboard from '../components/admin/AdminDashboard';
import UserManagement from '../components/admin/UserManagement';
import Broadcast from '../components/admin/Broadcast';
import Settings from '../components/admin/Settings';
import Blacklist from '../components/admin/Blacklist';
import RedeemCodes from '../components/admin/RedeemCodes';
import AdminManagement from '../components/admin/AdminManagement';
import SmsLogs from '../components/admin/SmsLogs';
import Transactions from '../components/admin/Transactions';
import BroadcastHistory from '../components/admin/BroadcastHistory';
import NotFoundPage from './NotFoundPage';
import { styleText } from '../constants';
import { ChartPieIcon, UsersIcon, SpeakerWaveIcon, Cog6ToothIcon, ShieldExclamationIcon, TicketIcon, KeyIcon, EnvelopeIcon, BanknotesIcon, ClockIcon } from '@heroicons/react/24/outline';

const AdminPage: React.FC = () => {

    const commonLinkClasses = "flex items-center px-4 py-2.5 text-sm font-medium rounded-lg transition-colors duration-200";
    const activeLinkClasses = "bg-blue-600 text-white shadow";
    const inactiveLinkClasses = "text-gray-300 hover:bg-gray-700/50 hover:text-white";

    const navLink = ({ isActive }: { isActive: boolean }) => 
        `${commonLinkClasses} ${isActive ? activeLinkClasses : inactiveLinkClasses}`;

    const menuItems = [
        { path: '/admin', name: 'Dashboard', icon: ChartPieIcon },
        { path: 'users', name: 'User Management', icon: UsersIcon },
        { path: 'broadcast', name: 'Broadcast', icon: SpeakerWaveIcon },
        { path: 'sms-logs', name: 'SMS Logs', icon: EnvelopeIcon },
        { path: 'transactions', name: 'Transactions', icon: BanknotesIcon },
        { path: 'redeem-codes', name: 'Redeem Codes', icon: TicketIcon },
        { path: 'blacklist', name: 'Blacklist', icon: ShieldExclamationIcon },
        { path: 'broadcast-history', name: 'Broadcast History', icon: ClockIcon },
        { path: 'admins', name: 'Admin Management', icon: KeyIcon },
        { path: 'settings', name: 'Settings', icon: Cog6ToothIcon },
    ];
  
    return (
        <div className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
            <div className="flex flex-col md:flex-row gap-8">
                <aside className="md:w-64 flex-shrink-0 px-4">
                    <h2 className="text-2xl font-bold text-white mb-6">{styleText('Admin Panel')}</h2>
                    <nav className="space-y-2">
                        {menuItems.map(item => (
                             <NavLink key={item.name} to={item.path} className={navLink} end={item.path === '/admin'}>
                                <item.icon className="h-5 w-5 mr-3"/>
                                {styleText(item.name)}
                             </NavLink>
                        ))}
                    </nav>
                </aside>

                <main className="flex-1 bg-gray-800 rounded-2xl shadow-xl p-6 min-h-[60vh]">
                    <Routes>
                        <Route index element={<AdminDashboard />} />
                        <Route path="users" element={<UserManagement />} />
                        <Route path="broadcast" element={<Broadcast />} />
                        <Route path="sms-logs" element={<SmsLogs />} />
                        <Route path="transactions" element={<Transactions />} />
                        <Route path="settings" element={<Settings />} />
                        <Route path="blacklist" element={<Blacklist />} />
                        <Route path="redeem-codes" element={<RedeemCodes />} />
                        <Route path="broadcast-history" element={<BroadcastHistory />} />
                        <Route path="admins" element={<AdminManagement />} />
                        <Route path="*" element={<NotFoundPage />} />
                    </Routes>
                </main>
            </div>
        </div>
    );
};

export default AdminPage;
