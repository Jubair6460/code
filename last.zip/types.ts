export interface User {
  id: number;
  username: string;
  password?: string; // Stored for mock purposes, would be hashed in a real backend
  firstName: string;
  diamonds: number;
  totalSmss: number;
  referralCode: string;
  referredBy: number | null;
  referralCount: number;
  dailyBonusClaimed: string | null;
  joinedDate: string;
  lastActive: string;
  isBlocked: boolean;
  isAdmin: boolean;
  safelist: SafeListItem[];
  lastReadBroadcastTimestamp: string | null;
}

export interface Transaction {
  id: string;
  userId: number;
  username: string;
  amount: number;
  reason: string;
  timestamp: string;
}

export interface SmsLog {
  id: string;
  userId: number;
  username: string;
  targetNumber: string;
  amount: number;
  cost: number;
  timestamp: string;
  status: 'started' | 'completed' | 'failed';
}

export interface BroadcastLog {
    id: string;
    adminId: number;
    message: string;
    sentAt: string;
    stats: { success: number; failed: number };
}

export interface SafeListItem {
  phoneNumber: string;
  note: string;
  addedAt: string;
}

export interface BlacklistItem {
    phoneNumber: string;
    reason: string;
    addedBy: number;
    addedAt: string;
}

export interface RedeemCode {
    code: string;
    amount: number;
    maxUsers: number;
    usedBy: number[];
    isActive: boolean;
    createdAt: string;
    createdBy: number;
}

export interface SystemSettings {
    maintenanceMode: boolean;
    dailyBonus: number;
    referralBonus: number;
    smsCost: number;
    apiKey: string;
    maxSmsAmount: number;
    maxReferrals: number;
    smsApiUrl: string;
    requestTimeout: number;
}